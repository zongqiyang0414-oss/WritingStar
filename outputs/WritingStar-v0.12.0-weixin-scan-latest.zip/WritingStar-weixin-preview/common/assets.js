"use strict";exports._imports_0="/static/brand/writingstar-logo-horizontal-transparent.png";
