"use strict";exports.growthIllustration="/static/growth.png";
