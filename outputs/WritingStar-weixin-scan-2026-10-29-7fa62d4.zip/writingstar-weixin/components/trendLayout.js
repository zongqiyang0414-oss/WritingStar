"use strict";exports.TREND_PADDING={left:32,right:12,top:14,bottom:26};
